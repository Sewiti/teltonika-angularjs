import { LithuanianDateAdapter } from './lithuanian-date-adapter';

describe('LithuanianDateAdapter', () => {
  it('should create an instance', () => {
    expect(new LithuanianDateAdapter()).toBeTruthy();
  });
});
